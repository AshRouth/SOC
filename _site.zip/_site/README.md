# Standing Orders Committee - Agenda Website

This is the SOC website for compiling and displaying motions for Green Party conference. Motion data is taken from the Green Spaces forum and displayed here, with co-proposer numbers updated regularly by SOC. Please don't try to amend motion text via pull request.

This site uses Jekyll and Bootstrap. It is the work of a pair of amateur volunteers, doing their best to make this information as easily accessible as possible, both at conference and beforehand. For more information, please contact SOC.
